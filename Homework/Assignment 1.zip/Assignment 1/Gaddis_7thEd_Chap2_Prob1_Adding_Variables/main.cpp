/* 
 * File:   main.cpp
 * Author: C. Phillip Lierz
 * Purpose: Day Four Classwork
 * Created on June 26, 2014, 10:00 AM
 */

//System Libraries
#include <iostream>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution
int main(int argc, char** argv) {

    //Define Variables
    unsigned short A=62;
    unsigned short B=99;
    unsigned short Total;

    //Calculations
    Total=A+B;

    //Output
    cout<<"The total of the variables A and B is "<<Total<<endl;
    
    return 0;
}

